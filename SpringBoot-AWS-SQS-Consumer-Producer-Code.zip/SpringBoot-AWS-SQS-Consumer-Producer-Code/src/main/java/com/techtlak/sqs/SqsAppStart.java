/**
 * @author debpaul
 *
 */

package com.techtlak.sqs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SqsAppStart {

	public static void main(String[] args) {
		SpringApplication.run(SqsAppStart.class, args);
	}
}
